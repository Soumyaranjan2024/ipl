import numpy as np
import pandas as pd
import os
import random
from pathlib import Path

random.seed(42)
np.random.seed(42)

TEAMS = [
    "Chennai Super Kings", "Mumbai Indians", "Royal Challengers Bangalore",
    "Kolkata Knight Riders", "Delhi Capitals", "Rajasthan Royals",
    "Punjab Kings", "Sunrisers Hyderabad", "Gujarat Titans", "Lucknow Super Giants"
]

TEAM_ABBREV = {
    "Chennai Super Kings": "CSK", "Mumbai Indians": "MI",
    "Royal Challengers Bangalore": "RCB", "Kolkata Knight Riders": "KKR",
    "Delhi Capitals": "DC", "Rajasthan Royals": "RR",
    "Punjab Kings": "PBKS", "Sunrisers Hyderabad": "SRH",
    "Gujarat Titans": "GT", "Lucknow Super Giants": "LSG",
    "Kings XI Punjab": "KXIP", "Delhi Daredevils": "DD",
    "Deccan Chargers": "DCH", "Rising Pune Supergiant": "RPS",
    "Rising Pune Supergiants": "RPS", "Gujarat Lions": "GL",
    "Pune Warriors": "PWI", "Kochi Tuskers Kerala": "KTK",
    "Royal Challengers Bengaluru": "RCB"
}

# Initial placeholders, will be overwritten by load_real_data()
TEAM_BATTERS = {}
TEAM_BOWLERS = {}
BATTER_AGGRESSION = {}
BOWLER_ECONOMY = {}

def get_phase(over):
    if over < 6: return 0
    elif over < 15: return 1
    else: return 2

def load_real_data():
    global TEAM_BATTERS, TEAM_BOWLERS, TEAMS, BATTER_AGGRESSION, BOWLER_ECONOMY
    
    matches_path = "data/matches.csv"
    balls_path = "data/balls.csv"
    
    if not os.path.exists(matches_path) or not os.path.exists(balls_path):
        print("[WARN] Real data CSVs not found. Using minimal defaults.")
        return False

    try:
        df_matches = pd.read_csv(matches_path)
        df_balls = pd.read_csv(balls_path)
        
        # Update TEAMS
        TEAMS = sorted(list(df_matches['team1'].unique()))
        
        # Update Rosters
        TEAM_BATTERS = {}
        TEAM_BOWLERS = {}
        
        for team in TEAMS:
            # Get batters who have played for this team
            team_balls = df_balls[df_balls['batting_team'] == team]
            top_batters = team_balls.groupby('batter')['runs_scored'].sum().sort_values(ascending=False).head(30).index.tolist()
            TEAM_BATTERS[team] = top_batters
            
            # Get bowlers who have bowled for this team
            team_bowling = df_balls[df_balls['bowling_team'] == team]
            top_bowlers = team_bowling.groupby('bowler')['is_wicket'].sum().sort_values(ascending=False).head(20).index.tolist()
            TEAM_BOWLERS[team] = top_bowlers

        # Update Aggression/Economy from data
        batter_stats = df_balls.groupby('batter').agg({'runs_scored': 'sum', 'ball': 'count'})
        # Filter for players with at least 50 balls
        batter_stats = batter_stats[batter_stats['ball'] > 50].copy()
        batter_stats['sr'] = (batter_stats['runs_scored'] / batter_stats['ball']) * 100
        avg_sr = batter_stats['sr'].mean()
        
        BATTER_AGGRESSION.clear()
        BATTER_AGGRESSION.update((batter_stats['sr'] / avg_sr).to_dict())

        bowler_stats = df_balls.groupby('bowler').agg({'runs_scored': 'sum', 'ball': 'count'})
        bowler_stats = bowler_stats[bowler_stats['ball'] > 50].copy()
        bowler_stats['eco'] = (bowler_stats['runs_scored'] / bowler_stats['ball']) * 6
        
        BOWLER_ECONOMY.clear()
        BOWLER_ECONOMY.update(bowler_stats['eco'].to_dict())

        print(f"[OK] Pipeline initialized with {len(TEAMS)} teams and {len(df_balls)} delivery records.")
        return True
    except Exception as e:
        print(f"[ERR] Loading real data failed: {e}")
        return False

def load_data():
    matches_path = "data/matches.csv"
    balls_path = "data/balls.csv"
    if not os.path.exists(matches_path) or not os.path.exists(balls_path):
        return pd.DataFrame(), pd.DataFrame()
    return pd.read_csv(matches_path), pd.read_csv(balls_path)

# Initialize on import
load_real_data()

def generate_ipl_data(data_dir="data"):
    # This is now just a check wrapper
    return os.path.exists(f"{data_dir}/balls.csv")

if __name__ == "__main__":
    load_real_data()
