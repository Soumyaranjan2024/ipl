import pandas as pd
import numpy as np
import joblib
import os
from pathlib import Path
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from data_pipeline import load_data


def build_features(df_balls):
    """Build ML features from innings-2 ball-by-ball data."""
    df2 = df_balls[df_balls['innings'] == 2].copy()
    df2 = df2[df2['target'] > 0].copy()

    df2['balls_used'] = df2['over'] * 6 + df2['ball']
    df2['total_balls'] = 120
    df2['balls_remaining'] = df2['total_balls'] - df2['balls_used']
    df2['run_rate'] = df2['total_score'] / (df2['balls_used'] / 6 + 0.01)
    df2['runs_needed'] = df2['target'] - df2['total_score']
    df2['req_rate'] = df2['runs_needed'] / (df2['balls_remaining'] / 6 + 0.01)
    df2['rr_diff'] = df2['run_rate'] - df2['req_rate']
    df2['wickets_in_hand'] = 10 - df2['wickets_fallen']
    df2['over_progress'] = df2['over'] / 20.0
    df2['score_pressure'] = df2['runs_needed'] / (df2['target'] + 1)

    features = [
        'over', 'ball', 'balls_remaining', 'total_score',
        'wickets_fallen', 'wickets_in_hand', 'target',
        'run_rate', 'req_rate', 'rr_diff',
        'phase', 'over_progress', 'score_pressure'
    ]
    df2 = df2.dropna(subset=features + ['batting_team_won'])
    df2 = df2[df2['balls_remaining'] >= 0]
    df2 = df2[df2['runs_needed'] >= 0]

    X = df2[features]
    y = df2['batting_team_won']
    return X, y


def train_model(data_dir="data", model_dir="models"):
    Path(model_dir).mkdir(exist_ok=True)
    _, df_balls = load_data(data_dir)

    print("Building features...")
    X, y = build_features(df_balls)
    print(f"Training on {len(X)} samples with XGBoost...")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = xgb.XGBClassifier(
        n_estimators=200,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        use_label_encoder=False,
        eval_metric='logloss'
    )
    model.fit(X_train, y_train)

    acc = accuracy_score(y_test, model.predict(X_test))
    print(f"[OK] Model accuracy: {acc:.3f}")

    joblib.dump(model, f"{model_dir}/win_prob_model.joblib")
    print(f"[OK] Model saved to {model_dir}/win_prob_model.joblib")
    return model


def load_model(model_dir="models"):
    path = f"{model_dir}/win_prob_model.joblib"
    if os.path.exists(path):
        return joblib.load(path)
    print("Model not found, training now...")
    return train_model(model_dir=model_dir)


def predict_win_probability(model, match_state: dict) -> float:
    """
    Predict win probability for the BATTING team in innings 2.
    match_state keys: over, ball, total_score, wickets_fallen, target
    Returns probability (0.0 to 1.0) of batting team winning.
    """
    from data_pipeline import BATTER_AGGRESSION, BOWLER_ECONOMY

    over = match_state.get('over', 0)
    ball = match_state.get('ball', 1)
    total_score = match_state.get('total_score', 0)
    wickets_fallen = match_state.get('wickets_fallen', 0)
    target = match_state.get('target', 160)
    innings = match_state.get('innings', 2)
    current_batter = match_state.get('current_batter')
    current_bowler = match_state.get('current_bowler')

    balls_used = over * 6 + ball
    balls_remaining = max(0, 120 - balls_used)
    run_rate = total_score / max(balls_used / 6, 0.1)
    runs_needed = max(0, target - total_score)
    req_rate = runs_needed / max(balls_remaining / 6, 0.1)
    rr_diff = run_rate - req_rate
    wickets_in_hand = 10 - wickets_fallen

    if over < 6:
        phase = 0
    elif over < 15:
        phase = 1
    else:
        phase = 2

    over_progress = over / 20.0
    score_pressure = runs_needed / (target + 1)

    if innings == 1:
        # For innings 1, estimate based on projected total and wickets in hand
        # Average IPL 1st innings score is ~175
        balls_used = over * 6 + ball - 1
        if balls_used < 12:
            # First two overs, use historical par with slight toss adjustment
            prob = 0.5
        else:
            current_rr = (total_score / balls_used) * 6
            # Blend current RR with average RR (8.5) - more weight to current RR as over progresses
            progression = balls_used / 120
            blended_rr = (current_rr * progression) + (8.5 * (1 - progression))
            projected_total = blended_rr * 20
            
            # Wicket pressure: each wicket lost reduces projected total by ~15 runs (increased from 12)
            avg_wickets_at_stage = balls_used / 12
            wicket_pressure = (wickets_fallen - avg_wickets_at_stage) * 15
            adjusted_projection = projected_total - wicket_pressure
            
            # Par score for a competitive match is ~175
            # Sensitivity: 1% shift per 1.5 runs away from par (increased from 2.0)
            prob = 0.5 + (adjusted_projection - 175) * 0.0066
        
        # Apply toss impact: Fielding first (chasing) is ~10% advantage (increased from 8%)
        toss_winner = match_state.get('toss_winner')
        toss_decision = match_state.get('toss_decision')
        batting_team = match_state.get('batting_team')
        
        if toss_winner and batting_team:
            is_chasing_team_advantage = False
            if toss_winner == batting_team:
                if toss_decision == 'field': is_chasing_team_advantage = True
            else:
                if toss_decision == 'bat': is_chasing_team_advantage = True
            
            if is_chasing_team_advantage:
                prob -= 0.10
            else:
                prob += 0.10
                
        return round(float(np.clip(prob, 0.05, 0.95)), 4)

    # Already won/lost checks
    if innings == 2:
        if total_score >= target:
            return 1.0
        if balls_remaining == 0:
            return 0.0
        if wickets_fallen >= 10:
            return 0.0

    features = pd.DataFrame([{
        'over': over, 'ball': ball, 'balls_remaining': balls_remaining,
        'total_score': total_score, 'wickets_fallen': wickets_fallen,
        'wickets_in_hand': wickets_in_hand, 'target': target,
        'run_rate': run_rate, 'req_rate': req_rate, 'rr_diff': rr_diff,
        'phase': phase, 'over_progress': over_progress, 'score_pressure': score_pressure
    }])

    # Base probability from XGBoost
    prob = model.predict_proba(features)[0][1]

    # Manual adjustment for toss impact (approx 8% shift)
    toss_winner = match_state.get('toss_winner')
    toss_decision = match_state.get('toss_decision')
    batting_team = match_state.get('batting_team')
    
    if toss_winner and batting_team:
        # If batting team won toss and chose to bat, or if they are chasing and opponent won toss and batted
        is_toss_advantage = False
        if toss_winner == batting_team:
            # We won the toss
            if toss_decision == 'field': is_toss_advantage = True # Bowling first is generally an advantage in IPL
            else: is_toss_advantage = False
        else:
            # Opponent won the toss
            if toss_decision == 'bat': is_toss_advantage = True # Opponent batting first means we bowl first (advantage)
            else: is_toss_advantage = False
            
        if is_toss_advantage:
            prob = prob + 0.10 # Increased from 0.08
        else:
            prob = prob - 0.10 # Increased from 0.08

    # Manual adjustment for player impact if data exists
    if current_batter in BATTER_AGGRESSION:
        # Aggression index > 1.0 means batter is above average
        # Increase sensitivity: shift up to 20% (increased from 15%)
        agg_factor = (BATTER_AGGRESSION[current_batter] - 1.0) * 0.8
        prob += agg_factor
        
    if current_bowler in BOWLER_ECONOMY:
        # Economy < 8.5 means bowler is above average (decreases batting team's prob)
        # Increase sensitivity: shift up to 12% (increased from 10%)
        eco_factor = (8.5 - BOWLER_ECONOMY[current_bowler]) * 0.06
        prob -= eco_factor

    return round(float(np.clip(prob, 0.01, 0.99)), 4)


if __name__ == "__main__":
    train_model()
