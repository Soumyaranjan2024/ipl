from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import copy

from data_pipeline import BATTER_AGGRESSION, BOWLER_ECONOMY, TEAM_BATTERS, TEAM_BOWLERS
from ml_model import load_model, predict_win_probability
from analytics import (
    get_toss_impact, get_phase_analysis,
    get_top_batters, get_top_bowlers,
    get_season_trends, get_team_performance
)

app = FastAPI(title="IPL Win Intelligence API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load ML model on startup
model = None

@app.on_event("startup")
def startup_event():
    global model
    print("Loading ML model...")
    model = load_model()
    print("[OK] API Ready")

# ── Real-time Broadcast Manager ───────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

@app.websocket("/ws/match-updates")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection alive
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# ── Analytics Endpoints ───────────────────────────────────────────────────────

@app.get("/api/analytics/toss-impact")
def toss_impact():
    return get_toss_impact()

@app.get("/api/analytics/phase-analysis")
def phase_analysis():
    return get_phase_analysis()

@app.get("/api/analytics/top-batters")
def top_batters(n: int = 10):
    return get_top_batters(n)

@app.get("/api/analytics/top-bowlers")
def top_bowlers(n: int = 10):
    return get_top_bowlers(n)

@app.get("/api/analytics/season-trends")
def season_trends():
    return get_season_trends()

@app.get("/api/analytics/team-performance")
def team_performance():
    return get_team_performance()

# ── Match Simulation Endpoints ────────────────────────────────────────────────

class MatchState(BaseModel):
    innings: int = 2
    over: int = 0
    ball: int = 1
    total_score: int = 0
    wickets_fallen: int = 0
    target: int = 160
    batting_team: str = ""
    bowling_team: str = ""
    current_batter: Optional[str] = None
    current_bowler: Optional[str] = None
    last_event: Optional[str] = None
    non_striker: Optional[str] = None
    status: str = "Ongoing" # "Ongoing" or "Completed"
    batting_order: List[str] = []
    bowling_order: List[str] = []
    toss_winner: Optional[str] = None
    toss_decision: Optional[str] = None


class BallLog(BaseModel):
    balls: List[dict]
    target: int
    batting_team: str
    toss_winner: Optional[str] = None
    toss_decision: Optional[str] = None


class ScenarioState(BaseModel):
    innings: int = 2
    over: int = 10
    ball: int = 3
    total_score: int = 80
    wickets_fallen: int = 3
    target: int = 160
    batting_team: str = ""
    bowling_team: str = ""
    current_batter: Optional[str] = None
    current_bowler: Optional[str] = None


@app.get("/api/teams")
def get_teams():
    from data_pipeline import TEAMS, TEAM_ABBREV
    return [{"name": t, "abbrev": TEAM_ABBREV.get(t, t[:3].upper())} for t in TEAMS]

@app.get("/api/team-players/{team_name}")
def get_team_players(team_name: str):
    from data_pipeline import TEAM_BATTERS, TEAM_BOWLERS
    batters = TEAM_BATTERS.get(team_name, [])
    bowlers = TEAM_BOWLERS.get(team_name, [])
    return {"batters": batters, "bowlers": bowlers}


@app.post("/api/match/player-impact/{team_name}")
def player_impact(team_name: str, state: MatchState):
    from data_pipeline import TEAM_BATTERS, TEAM_BOWLERS, BATTER_AGGRESSION, BOWLER_ECONOMY
    batters = TEAM_BATTERS.get(team_name, [])
    bowlers = TEAM_BOWLERS.get(team_name, [])
    
    impacts = []
    current_prob = predict_win_probability(model, state.dict())
    
    # Calculate impact for top 5 batters not currently playing
    available_batters = [b for b in batters if b != state.current_batter and b != state.non_striker][:5]
    for batter in available_batters:
        s = state.dict()
        s['current_batter'] = batter
        new_prob = predict_win_probability(model, s)
        delta = round((new_prob - current_prob) * 100, 1)
        # Force a minimum impact based on aggression if delta is too small
        if abs(delta) < 0.1 and batter in BATTER_AGGRESSION:
            delta = round((BATTER_AGGRESSION[batter] - 1.0) * 15, 1)
        
        impact_text = f"If {batter} comes now, it changes win chance by {delta}%"
        impacts.append({"player": batter, "type": "batter", "impact": delta, "explanation": impact_text})
        
    # Calculate impact for top 5 bowlers not currently bowling
    available_bowlers = [b for b in bowlers if b != state.current_bowler][:5]
    for bowler in available_bowlers:
        s = state.dict()
        s['current_bowler'] = bowler
        new_prob = predict_win_probability(model, s)
        # For bowling team, we want to see how much it decreases batting team's prob
        delta = round((current_prob - new_prob) * 100, 1)
        if abs(delta) < 0.1 and bowler in BOWLER_ECONOMY:
            delta = round((8.5 - BOWLER_ECONOMY[bowler]) * 2, 1)
            
        impact_text = f"Bowler {bowler} can shift win prob by {delta}% in this situation."
        impacts.append({"player": bowler, "type": "bowler", "impact": delta, "explanation": impact_text})
        
    return sorted(impacts, key=lambda x: abs(x['impact']), reverse=True)


@app.post("/api/match/phase-impact")
def phase_impact(state: MatchState):
    # Returns win probability impact based on current phase
    over = state.over
    wickets = state.wickets_fallen
    
    if over < 6: 
        phase = "Powerplay"
        impact = 8.0 + (wickets * 1.5) 
    elif over < 15: 
        phase = "Middle"
        impact = 4.0 + (wickets * 0.8)
    else: 
        phase = "Death"
        impact = 12.0 + (wickets * 2.0)
    
    impact = round(max(1.0, impact), 1)
    
    descriptions = {
        "Powerplay": f"Powerplay: Fielding restrictions apply. Each wicket here is worth ~{round(impact/2, 1)}% win chance.",
        "Middle": f"Middle overs: Match is stabilizing. Volatility is moderate at {impact}%.",
        "Death": f"Death overs: Deciding this match based on past IPL data. High intensity phase!"
    }
    
    return {
        "phase": phase,
        "impact": impact,
        "description": descriptions.get(phase, "Match is in a critical transition phase.")
    }


@app.get("/api/dataset-stats")
def dataset_stats():
    from data_pipeline import load_data
    df_matches, df_balls = load_data()
    if df_matches.empty or df_balls.empty:
        return {"connected": False}
    
    seasons = sorted(df_matches['season'].unique().tolist()) if 'season' in df_matches.columns else []
    return {
        "connected": True,
        "total_matches": len(df_matches),
        "total_balls": len(df_balls),
        "seasons": seasons,
        "seasons_count": len(seasons)
    }


@app.get("/api/analytics/toss-impact")
def toss_impact_analytics():
    from analytics import get_toss_impact
    return get_toss_impact()


# ── Win Intelligence Endpoints ───────────────────────────────────────────────

@app.post("/api/match/win-probability")
def win_probability(state: MatchState):
    prob = predict_win_probability(model, state.dict())
    
    # Calculate status
    balls_used = state.over * 6 + (state.ball - 1)
    balls_left = 120 - balls_used
    
    status = "Ongoing"
    runs_needed = 0
    explanation = ""
    
    if state.innings == 1:
        if state.wickets_fallen >= 10 or balls_used >= 120:
            status = "Completed"
        
        # 1st innings explanation
        projected = round((state.total_score / max(balls_used, 1)) * 120)
        explanation = f"1st Innings: Batting team is on track for {projected}. Win probability: {round(prob*100)}%."
    else:
        # 2nd innings
        runs_needed = state.target - state.total_score
        if runs_needed <= 0:
            status = "Completed"
        elif state.wickets_fallen >= 10 or balls_left <= 0:
            status = "Completed"
            
        # 2nd innings explanation
        if status == "Ongoing":
            explanation = f"Need {runs_needed} runs from {balls_left} balls. Match intensity is high!"
            if balls_left < 30:
                explanation += " Death overs are deciding this match based on past IPL data."
        else:
            explanation = "Match completed."

    return {
        "win_probability": prob,
        "batting_team_win_pct": round(prob * 100, 1),
        "bowling_team_win_pct": round((1 - prob) * 100, 1),
        "status": status,
        "runs_needed": max(0, runs_needed),
        "balls_left": max(0, balls_left),
        "explanation": explanation
    }


@app.post("/api/match/commentary")
def generate_commentary(state: MatchState):
    s = state.dict()
    over = s['over']
    wickets = s['wickets_fallen']
    score = s['total_score']
    target = s['target']
    batter = s.get('current_batter') or "the batter"
    bowler = s.get('current_bowler') or "the bowler"
    last = s.get('last_event', 'dot')
    innings = s.get('innings', 2)

    balls_used = over * 6 + s.get('ball', 1)
    balls_remaining = max(1, 120 - balls_used)
    runs_needed = max(0, target - score)
    req_rr = round(runs_needed / (balls_remaining / 6), 2) if balls_remaining > 0 else 99
    curr_rr = round(score / max(balls_used / 6, 0.1), 2)

    batter_agg = BATTER_AGGRESSION.get(batter, 1.0)
    bowler_eco = BOWLER_ECONOMY.get(bowler, 8.5)

    if over < 6: phase_label = "Powerplay"
    elif over < 15: phase_label = "middle overs"
    else: phase_label = "death overs"

    comments = []
    event_map = {
        "dot": f"Dot ball! {bowler} keeps it tight. Pressure building on {batter}.",
        "1": f"Quick single taken. {batter} rotates strike smartly.",
        "2": f"Two runs. Good running between the wickets.",
        "3": f"Three! Excellent running. {batter} showing great intent.",
        "4": f"FOUR! {batter} finds the gap beautifully. Crowd goes wild!",
        "6": f"SIX! {batter} launches it over the stands! Massive!",
        "W": f"WICKET! {batter} is OUT! {bowler} strikes at a crucial moment!",
        "wide": f"Wide! {bowler} loses control -- extra ball and run for the batting team.",
        "nb": f"No-ball! Free hit coming up -- great opportunity for the batting team.",
    }
    comments.append(event_map.get(last, f"Ball delivered. {batter} faces {bowler}."))

    if innings == 2:
        if runs_needed <= 0:
            comments.append(f"🏆 Target achieved! {s.get('batting_team', 'Batting team')} wins!")
        elif req_rr > curr_rr + 3:
            comments.append(f"📊 Required rate ({req_rr}) is significantly higher than current rate ({curr_rr}). {batter} needs to attack NOW.")
        elif req_rr < curr_rr - 2:
            comments.append(f"😌 Comfortable position — current rate ({curr_rr}) well ahead of required ({req_rr}).")
        else:
            comments.append(f"⚖️ Balanced contest! Required: {req_rr} rpo. Every ball matters in the {phase_label}.")

    # AI Predictive Analytics
    current_prob = predict_win_probability(model, s)
    
    # Boundary impact
    state_copy = s.copy()
    state_copy['total_score'] = score + 4
    prob_four = predict_win_probability(model, state_copy)
    four_delta = round((prob_four - current_prob) * 100, 1)

    state_copy_six = s.copy()
    state_copy_six['total_score'] = score + 6
    prob_six = predict_win_probability(model, state_copy_six)
    six_delta = round((prob_six - current_prob) * 100, 1)

    # Wicket impact (Rewriter style)
    state_copy_wicket = s.copy()
    state_copy_wicket['wickets_fallen'] = min(10, wickets + 1)
    prob_wicket = predict_win_probability(model, state_copy_wicket)
    wicket_delta = round((current_prob - prob_wicket) * 100, 1)

    if innings == 2:
        comments.append(f"🎯 AI Insight: {batter} surviving is critical. A wicket here drops win probability by {wicket_delta}% to {round(prob_wicket*100, 1)}%.")
        if four_delta > 5:
            comments.append(f"⚡ Opportunity: A boundary now shifts probability by +{four_delta}%.")

    return {"commentary": comments, "current_win_prob": current_prob}


class ScenarioState(BaseModel):
    innings: int = 2
    over: int = 10
    ball: int = 3
    total_score: int = 80
    wickets_fallen: int = 3
    target: int = 160
    batting_team: str = ""
    bowling_team: str = ""
    current_batter: Optional[str] = None
    current_bowler: Optional[str] = None


@app.post("/api/match/scenario")
def scenario_simulator(state: ScenarioState):
    base = state.dict()
    base_prob = predict_win_probability(model, base)

    def mutate(changes):
        s = copy.deepcopy(base)
        s.update(changes)
        return predict_win_probability(model, s)

    scenarios = [
        {
            "id": "wicket_now",
            "label": "Wicket Now",
            "description": "What if a wicket falls this ball?",
            "before": round(base_prob * 100, 1),
            "after": round(mutate({"wickets_fallen": min(10, base['wickets_fallen'] + 1)}) * 100, 1),
            "delta": round((mutate({"wickets_fallen": min(10, base['wickets_fallen'] + 1)}) - base_prob) * 100, 1),
            "impact": "negative"
        },
        {
            "id": "six_now",
            "label": "Six Now",
            "description": "What if the batter hits a six?",
            "before": round(base_prob * 100, 1),
            "after": round(mutate({"total_score": base['total_score'] + 6}) * 100, 1),
            "delta": round((mutate({"total_score": base['total_score'] + 6}) - base_prob) * 100, 1),
            "impact": "positive"
        },
        {
            "id": "dot_ball",
            "label": "Dot Ball",
            "description": "What if the next ball is a dot?",
            "before": round(base_prob * 100, 1),
            "after": round(mutate({"ball": min(6, base['ball'] + 1)}) * 100, 1),
            "delta": round((mutate({"ball": min(6, base['ball'] + 1)}) - base_prob) * 100, 1),
            "impact": "negative"
        },
    ]

    return {"base_probability": round(base_prob * 100, 1), "scenarios": scenarios}


@app.post("/api/match/turning-points")
def turning_points(log: BallLog):
    balls = log.balls
    if len(balls) < 2: return {"turning_points": [], "probability_timeline": []}
    
    probs = []
    # Initial state probability (Start)
    start_state = {
        "innings": 2, "over": 0, "ball": 1, "total_score": 0, "wickets_fallen": 0,
        "target": log.target, "batting_team": log.batting_team,
        "toss_winner": log.toss_winner, "toss_decision": log.toss_decision
    }
    probs.append(predict_win_probability(model, start_state))

    for b in balls:
        state = {
            "innings": 2, 
            "over": b.get("over", 0), 
            "ball": b.get("ball", 1), 
            "total_score": b.get("total_score", 0), 
            "wickets_fallen": b.get("wickets_fallen", 0), 
            "target": log.target,
            "batting_team": log.batting_team,
            "bowling_team": b.get("bowling_team", ""),
            "current_batter": b.get("batter"),
            "current_bowler": b.get("bowler"),
            "toss_winner": log.toss_winner,
            "toss_decision": log.toss_decision
        }
        probs.append(predict_win_probability(model, state))

    turning = []
    for i in range(1, len(probs)):
        delta = abs(probs[i] - probs[i - 1])
        if delta >= 0.08:
            b = balls[i]
            direction = "↑" if probs[i] > probs[i - 1] else "↓"
            turning.append({
                "ball_index": i, "over": b.get("over", 0), "ball": b.get("ball", 1), "event": b.get("event", "ball"),
                "batter": b.get("batter", "Unknown"), "bowler": b.get("bowler", "Unknown"),
                "prob_before": round(probs[i - 1] * 100, 1), "prob_after": round(probs[i] * 100, 1),
                "delta": round(delta * 100, 1), "direction": direction,
                "narrative": f"{'🔥' if direction == '↑' else '💥'} Momentum swing! {b.get('batter' if direction == '↑' else 'bowler')}'s play shifted win prob by {round(delta*100, 1)}%."
            })
    return {"turning_points": turning, "probability_timeline": [round(p * 100, 1) for p in probs]}

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": model is not None}
