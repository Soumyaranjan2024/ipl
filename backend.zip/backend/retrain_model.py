from ml_model import train_model

if __name__ == "__main__":
    print("Retraining model with real IPL data...")
    train_model()
    print("Model training complete.")
