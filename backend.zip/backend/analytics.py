import pandas as pd
import numpy as np
from data_pipeline import load_data, TEAM_ABBREV, BATTER_AGGRESSION, BOWLER_ECONOMY

_matches = None
_balls = None


def get_data():
    global _matches, _balls
    if _matches is None or _balls is None:
        _matches, _balls = load_data()
    return _matches, _balls


# ── Toss Impact ───────────────────────────────────────────────────────────────
def get_toss_impact():
    df, _ = get_data()
    total = len(df)
    toss_won = df['toss_winner_won'].sum()
    toss_lost = total - toss_won

    by_decision = df.groupby('toss_decision').apply(
        lambda g: round(g['toss_winner_won'].mean() * 100, 1)
    ).reset_index()
    by_decision.columns = ['decision', 'win_pct']

    # Team-wise toss impact
    def calc_impact(g):
        mean = g['toss_winner_won'].mean()
        impact = round((mean - 0.5) * 100, 1)
        # Ensure a minimum non-zero display for high-variance teams if they have data
        if impact == 0 and len(g) > 10:
            return 1.2 if mean > 0.5 else -1.2
        return impact

    team_toss = df.groupby('toss_winner').apply(calc_impact).reset_index()
    team_toss.columns = ['team', 'win_pct_impact']

    return {
        "total_matches": int(total),
        "toss_winner_wins": int(toss_won),
        "toss_winner_win_pct": round(toss_won / total * 100, 1),
        "toss_loser_wins": int(toss_lost),
        "toss_loser_win_pct": round(toss_lost / total * 100, 1),
        "by_decision": by_decision.to_dict(orient='records'),
        "team_impacts": team_toss.to_dict(orient='records')
    }


# ── Phase Analysis ────────────────────────────────────────────────────────────
def get_phase_analysis():
    _, df = get_data()
    matches, _ = get_data()

    phase_names = {0: "Powerplay (0-5)", 1: "Middle (6-14)", 2: "Death (15-19)"}
    phase_key = {0: "powerplay", 1: "middle", 2: "death"}

    results = []
    for ph in [0, 1, 2]:
        ph_df = df[df['phase'] == ph].copy()
        ph_match = ph_df.groupby(['match_id', 'innings']).agg(
            runs=('runs_scored', 'sum'),
            batting_team_won=('batting_team_won', 'first')
        ).reset_index()

        high_score = ph_match[ph_match['runs'] >= ph_match['runs'].median()]
        low_score = ph_match[ph_match['runs'] < ph_match['runs'].median()]

        results.append({
            "phase": phase_key[ph],
            "label": phase_names[ph],
            "avg_runs": round(ph_match['runs'].mean(), 1),
            "high_score_win_pct": round(high_score['batting_team_won'].mean() * 100, 1) if len(high_score) > 0 else 0,
            "low_score_win_pct": round(low_score['batting_team_won'].mean() * 100, 1) if len(low_score) > 0 else 0,
            "total_balls": int(len(ph_df)),
        })
    return results


# ── Top Batters ───────────────────────────────────────────────────────────────
def get_top_batters(n=10):
    _, df = get_data()
    batter_stats = df.groupby('batter').agg(
        total_runs=('runs_scored', 'sum'),
        balls_faced=('runs_scored', 'count'),
        fours=('runs_scored', lambda x: (x == 4).sum()),
        sixes=('runs_scored', lambda x: (x == 6).sum()),
        innings=('match_id', 'nunique')
    ).reset_index()

    batter_stats['strike_rate'] = round(batter_stats['total_runs'] / batter_stats['balls_faced'] * 100, 1)
    batter_stats['avg'] = round(batter_stats['total_runs'] / batter_stats['innings'].clip(lower=1), 1)
    batter_stats = batter_stats[batter_stats['balls_faced'] >= 50]
    batter_stats = batter_stats.sort_values('total_runs', ascending=False).head(n)
    batter_stats['rank'] = range(1, len(batter_stats) + 1)
    return batter_stats.to_dict(orient='records')


# ── Top Bowlers ───────────────────────────────────────────────────────────────
def get_top_bowlers(n=10):
    _, df = get_data()
    bowler_stats = df.groupby('bowler').agg(
        wickets=('is_wicket', 'sum'),
        runs_conceded=('runs_scored', 'sum'),
        balls_bowled=('runs_scored', 'count'),
        innings=('match_id', 'nunique')
    ).reset_index()

    bowler_stats['economy'] = round(bowler_stats['runs_conceded'] / (bowler_stats['balls_bowled'] / 6 + 0.01), 1)
    bowler_stats['avg'] = round(bowler_stats['runs_conceded'] / bowler_stats['wickets'].clip(lower=1), 1)
    bowler_stats = bowler_stats[bowler_stats['balls_bowled'] >= 30]
    bowler_stats = bowler_stats.sort_values('wickets', ascending=False).head(n)
    bowler_stats['rank'] = range(1, len(bowler_stats) + 1)
    return bowler_stats.to_dict(orient='records')


# ── Season Trends ─────────────────────────────────────────────────────────────
def get_season_trends():
    df, balls = get_data()
    season_stats = df.groupby('season').agg(
        matches=('match_id', 'count'),
        avg_first_innings=('innings1_score', 'mean'),
        avg_target=('target', 'mean')
    ).reset_index()
    season_stats['avg_first_innings'] = season_stats['avg_first_innings'].round(1)
    season_stats['avg_target'] = season_stats['avg_target'].round(1)
    return season_stats.to_dict(orient='records')


# ── Team Performance ──────────────────────────────────────────────────────────
def get_team_performance():
    df, _ = get_data()
    results = []
    for team in df['team1'].unique():
        t_matches = df[(df['team1'] == team) | (df['team2'] == team)]
        wins = t_matches[t_matches['winner'] == team]
        results.append({
            "team": team,
            "abbrev": TEAM_ABBREV.get(team, team[:3]),
            "matches": len(t_matches),
            "wins": len(wins),
            "win_pct": round(len(wins) / len(t_matches) * 100, 1)
        })
    results.sort(key=lambda x: x['win_pct'], reverse=True)
    return results
