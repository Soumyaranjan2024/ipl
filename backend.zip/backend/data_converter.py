import os
import json
import pandas as pd
from pathlib import Path
from tqdm import tqdm

def convert_cricsheet_to_csv(json_dir="../ipl_male_json", output_dir="data"):
    Path(output_dir).mkdir(exist_ok=True)
    
    # Try current or parent
    json_path = Path(json_dir)
    if not json_path.exists():
        json_path = Path("ipl_male_json") # Try current if parent fails
    
    if not json_path.exists():
        print(f"[ERR] ipl_male_json not found in {os.getcwd()} or parent")
        return False

    all_matches = []
    all_balls = []
    
    files = list(json_path.glob("*.json"))
    print(f"Converting {len(files)} matches from {json_dir}...")

    for file in tqdm(files):
        try:
            with open(file, 'r') as f:
                data = json.load(f)
            
            info = data.get('info', {})
            match_id = file.stem
            
            # Match metadata
            teams = info.get('players', {}).keys()
            if len(teams) < 2: continue
            team1, team2 = list(teams)
            
            outcome = info.get('outcome', {})
            winner = outcome.get('winner', 'Draw')
            
            match_record = {
                'match_id': match_id,
                'season': info.get('dates', ['2023'])[0][:4],
                'team1': team1,
                'team2': team2,
                'venue': info.get('venue', 'Unknown'),
                'toss_winner': info.get('toss', {}).get('winner'),
                'toss_decision': info.get('toss', {}).get('decision'),
                'winner': winner,
                'toss_winner_won': 1 if info.get('toss', {}).get('winner') == winner else 0,
                'target': 0 
            }
            
            # Balls processing
            innings_list = data.get('innings', [])
            inn1_score = 0
            inn1_wickets = 0
            
            for idx, inn in enumerate(innings_list):
                inn_num = idx + 1
                batting_team = inn.get('team')
                bowling_team = team2 if batting_team == team1 else team1
                
                score = 0
                wickets = 0
                
                for over_data in inn.get('overs', []):
                    over_num = over_data.get('over')
                    for ball_idx, ball in enumerate(over_data.get('deliveries', [])):
                        runs = ball.get('runs', {}).get('total', 0)
                        batter_runs = ball.get('runs', {}).get('batter', 0)
                        extras = ball.get('runs', {}).get('extras', 0)
                        
                        is_wicket = 1 if 'wickets' in ball else 0
                        wickets += is_wicket
                        score += runs
                        
                        all_balls.append({
                            'match_id': match_id,
                            'innings': inn_num,
                            'over': over_num,
                            'ball': ball_idx + 1,
                            'batting_team': batting_team,
                            'bowling_team': bowling_team,
                            'batter': ball.get('batter'),
                            'bowler': ball.get('bowler'),
                            'runs_scored': batter_runs,
                            'is_wicket': is_wicket,
                            'total_score': score,
                            'wickets_fallen': wickets,
                            'phase': 0 if over_num < 6 else (1 if over_num < 15 else 2),
                            'match_winner': winner,
                            'batting_team_won': 1 if winner == batting_team else 0
                        })

                if inn_num == 1:
                    inn1_score = score
                    inn1_wickets = wickets
                    match_record['innings1_score'] = score
                    match_record['innings1_wickets'] = wickets
                    match_record['target'] = score + 1
                else:
                    match_record['innings2_score'] = score
                    match_record['innings2_wickets'] = wickets

            all_matches.append(match_record)
            
        except Exception as e:
            # print(f"Error processing {file}: {e}")
            continue

    if not all_matches:
        return False

    df_matches = pd.DataFrame(all_matches)
    df_balls = pd.DataFrame(all_balls)
    
    # Merge target from matches into balls
    df_balls = df_balls.merge(df_matches[['match_id', 'target']], on='match_id', how='left')
    
    df_matches.to_csv(f"{output_dir}/matches.csv", index=False)
    df_balls.to_csv(f"{output_dir}/balls.csv", index=False)
    
    print(f"[OK] Processed {len(df_matches)} matches and {len(df_balls)} balls")
    return True

if __name__ == "__main__":
    convert_cricsheet_to_csv()
