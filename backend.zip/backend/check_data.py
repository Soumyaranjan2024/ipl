from data_pipeline import BATTER_AGGRESSION, load_real_data
load_real_data()
print(f"Rahane: {BATTER_AGGRESSION.get('AM Rahane')}")
print(f"Jaiswal: {BATTER_AGGRESSION.get('YBK Jaiswal')}")
print(f"Watson: {BATTER_AGGRESSION.get('SR Watson')}")
print(f"Aggression count: {len(BATTER_AGGRESSION)}")
