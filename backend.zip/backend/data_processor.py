import os
import json
import pandas as pd
from pathlib import Path
from tqdm import tqdm

def process_ipl_json(json_dir, output_dir):
    json_dir = Path(json_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    match_list = []
    ball_list = []

    json_files = list(json_dir.glob("*.json"))
    print(f"Found {len(json_files)} JSON files. Processing...")

    for file_path in tqdm(json_files):
        with open(file_path, 'r') as f:
            data = json.load(f)

        info = data.get('info', {})
        match_id = file_path.stem
        
        # Match Info
        outcome = info.get('outcome', {})
        winner = outcome.get('winner')
        
        match_data = {
            'match_id': match_id,
            'season': info.get('season'),
            'date': info.get('dates', [None])[0],
            'venue': info.get('venue'),
            'team1': info.get('teams', [None, None])[0],
            'team2': info.get('teams', [None, None])[1],
            'toss_winner': info.get('toss', {}).get('winner'),
            'toss_decision': info.get('toss', {}).get('decision'),
            'winner': winner,
            'result_type': 'runs' if 'runs' in outcome.get('by', {}) else ('wickets' if 'wickets' in outcome.get('by', {}) else 'other'),
            'result_margin': outcome.get('by', {}).get('runs') or outcome.get('by', {}).get('wickets') or 0,
            'toss_winner_won': 1 if info.get('toss', {}).get('winner') == winner else 0
        }
        match_list.append(match_data)

        # Inning 1 Score for Target Calculation
        innings1_total = 0
        innings_data = data.get('innings', [])
        if len(innings_data) > 0:
            for over in innings_data[0].get('overs', []):
                for delivery in over.get('deliveries', []):
                    innings1_total += delivery.get('runs', {}).get('total', 0)
        
        target = innings1_total + 1

        # Ball by Ball
        for i, inning in enumerate(innings_data):
            batting_team = inning.get('team')
            bowling_team = match_data['team2'] if batting_team == match_data['team1'] else match_data['team1']
            
            cumulative_runs = 0
            cumulative_wickets = 0
            
            for over_data in inning.get('overs', []):
                over_num = over_data.get('over')
                deliveries = over_data.get('deliveries', [])
                
                for ball_idx, ball_data in enumerate(deliveries):
                    runs = ball_data.get('runs', {})
                    cumulative_runs += runs.get('total', 0)
                    
                    is_wicket = 1 if 'wickets' in ball_data else 0
                    cumulative_wickets += is_wicket
                    
                    ball_info = {
                        'match_id': match_id,
                        'innings': i + 1,
                        'batting_team': batting_team,
                        'bowling_team': bowling_team,
                        'over': over_num,
                        'ball': ball_idx + 1,
                        'batter': ball_data.get('batter'),
                        'bowler': ball_data.get('bowler'),
                        'runs_scored': runs.get('total', 0),
                        'total_score': cumulative_runs,
                        'wickets_fallen': cumulative_wickets,
                        'is_wicket': is_wicket,
                        'target': target if i == 1 else 0,
                        'phase': 0 if over_num < 6 else (1 if over_num < 15 else 2),
                        'batting_team_won': 1 if batting_team == winner else 0
                    }
                    ball_list.append(ball_info)

    # Save to CSV
    matches_df = pd.DataFrame(match_list)
    balls_df = pd.DataFrame(ball_list)
    
    matches_df.to_csv(output_dir / "matches.csv", index=False)
    balls_df.to_csv(output_dir / "balls.csv", index=False)
    
    print(f"Successfully processed {len(matches_df)} matches and {len(balls_df)} deliveries.")
    print(f"Data saved to {output_dir}")

if __name__ == "__main__":
    process_ipl_json(r"c:\Users\soumy\Desktop\ipl\ipl_male_json", r"c:\Users\soumy\Desktop\ipl\backend\data")
